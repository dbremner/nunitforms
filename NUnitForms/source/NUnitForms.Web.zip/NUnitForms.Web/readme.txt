This is a rough preview of how I might support asp.net page testing.  
Most of the code is duplicated from the winforms piece of NUnitForms.  

The original idea came from this blog entry from Steve Maine.  

http://hyperthink.net/blog/CommentView,guid,271632d2-07e3-41af-9e58-9a7e25348b8c.aspx

If I discover some interest, I will try to integrate this more tightly
into NUnitForms for a future release.

I have made some sample tests and they seem to work pretty well.



