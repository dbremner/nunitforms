#region Copyright (c) 2003-2004, Luke T. Maxon

/********************************************************************************************************************
'
' Copyright (c) 2003-2004, Luke T. Maxon
' All rights reserved.
' 
' Redistribution and use in source and binary forms, with or without modification, are permitted provided
' that the following conditions are met:
' 
' * Redistributions of source code must retain the above copyright notice, this list of conditions and the
' 	following disclaimer.
' 
' * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and
' 	the following disclaimer in the documentation and/or other materials provided with the distribution.
' 
' * Neither the name of the author nor the names of its contributors may be used to endorse or 
' 	promote products derived from this software without specific prior written permission.
' 
' THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
' WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
' PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
' ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
' LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
' INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
' OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
' IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
'
'*******************************************************************************************************************/

#endregion

using System;
using System.Collections;
using System.Text;
using System.Web;
using System.Web.Hosting;
using System.IO;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Messaging;
using System.Globalization;
using System.Web.SessionState;
using System.Reflection;
using System.Web.UI;

namespace NUnit.Extensions.Forms.Web
{
	[Serializable]
	public class NUnitFormsAspHost : MarshalByRefObject
	{
		private Hashtable formVariables = new Hashtable();

		public Hashtable FormVariables
		{
			get
			{
				return formVariables;
			}
		}

		private bool postBack = false;

		public bool PostBack
		{
			get
			{
				return postBack;
			}
			set
			{
				postBack = value;
			}
		}

		public void RunTest()
		{
			try
			{
				FormVariables["__EVENTTARGET"] = string.Empty;
				FormVariables["__EVENTARGUMENT"] = string.Empty;
				Test();
			}
			catch(Exception e)
			{
				writer.WriteLine(responseText.ToString());
				if (e.InnerException is NUnit.Framework.AssertionException)
				{
					throw e.InnerException;
				}
				if (e is HttpUnhandledException && e.InnerException != null)
				{
					writer.WriteLine(e.StackTrace);
					throw e.InnerException;
				}
				throw e;
			}
		}

		public virtual void Test()
		{
		}

		public string vDir;
		public string dir;
		public TextWriter writer;

		protected string testPage = string.Empty;

		private StringBuilder responseText = new StringBuilder();

		public StringBuilder ResponseText
		{
			get
			{
				return responseText;
			}
		}

		public HttpContext GetSimpleContext()
		{
			return GetSimpleContext(new StringWriter(ResponseText));
		}

		public HttpContext GetSimpleContext(TextWriter w)
		{
			CustomWorkerRequest r;
			return GetSimpleContext(w, out r);
		}

		public IHttpHandler GetPage(string page)
		{
			CustomWorkerRequest request;
			HttpContext context = GetSimpleContext(new StringWriter(responseText), out request);
			HttpRuntime.ProcessRequest( request);
			responseText = new StringBuilder();
			CallContext.SetData("HtCt", context);
			return PageParser.GetCompiledPageInstance( vDir + "/" + page, dir + "\\" + page, context);
		}

		public static object CreateApplicationHost(Type hostType, string virtualDir, string physicalDir, TextWriter writer) 
		{
			if (!(physicalDir.EndsWith("\\"))) physicalDir = physicalDir + "\\";

			AppDomain ad = GetAppDomain(virtualDir, physicalDir);

			ObjectHandle oh = ad.CreateInstance(hostType.Module.Assembly.FullName, hostType.FullName);

			NUnitFormsAspHost host = (NUnitFormsAspHost)oh.Unwrap(); 

			host.vDir = virtualDir;
			host.dir = physicalDir;
			host.writer = writer;

			return host;
		}

		private static Hashtable appDomains = new Hashtable();

		private static string key(string virtualDir, string physicalDir)
		{
			return virtualDir + " : " + physicalDir;
		}

		private static AppDomain GetCachedAppDomain(string virtualDir, string physicalDir)
		{
			return (AppDomain)appDomains[key(virtualDir, physicalDir)];
		}

		private static void SetAppDomain(string virtualDir, string physicalDir, AppDomain ad)
		{
			appDomains[key(virtualDir, physicalDir)] = ad;
		}

		private static AppDomain GetAppDomain(string virtualDir, string physicalDir)
		{
			string aspDir = HttpRuntime.AspInstallDirectory;
			string domainId = DateTime.Now.ToString(DateTimeFormatInfo.InvariantInfo).GetHashCode().ToString("x");
			string appName = (virtualDir + physicalDir).GetHashCode().ToString("x");

			AppDomain ad = GetCachedAppDomain(virtualDir, physicalDir);

			if (ad == null)
			{
				AppDomainSetup setup = new AppDomainSetup();
				setup.ApplicationName = appName;
				setup.ConfigurationFile = "web.config";  // not necessary execept for debugging

				ad = AppDomain.CreateDomain(domainId, null, setup);
				ad.SetData(".appDomain", "*");
				ad.SetData(".appPath", physicalDir);
				ad.SetData(".appVPath", virtualDir);
				ad.SetData(".domainId", domainId);
				ad.SetData(".hostingVirtualPath", virtualDir);
				ad.SetData(".hostingInstallDir", aspDir);
				
				SetAppDomain(virtualDir, physicalDir, ad);  //tests are much faster by caching the appdomain!!!!!
			}
			return ad;
		}

		private HttpContext GetSimpleContext(TextWriter w, out CustomWorkerRequest request)
		{
			request = new CustomWorkerRequest( testPage, null, w);
			request.GetOrPost = PostBack?"POST":"GET";
			request.formVariables = FormVariables;
			HttpContext context = new HttpContext(request);

			object o =  Activator.CreateInstance(typeof(HttpSessionState).Assembly.GetType("System.Web.SessionState.SessionDictionary"), true);

			HttpSessionState sessionState = (HttpSessionState)
				Activator.CreateInstance(typeof(HttpSessionState), 
				BindingFlags.NonPublic|BindingFlags.Instance, null, new object[]{"mySession", o, new HttpStaticObjectsCollection(), 30, true, false, SessionStateMode.InProc, false}, null);
			
			context.Items["AspSession"] = sessionState;

			return context;
		}
	}
}
